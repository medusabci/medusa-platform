﻿// TCP Client for communicating MEDUSA and Unity
//     > (Last edit)
//     > 29/09/2021
//     > Author: Víctor Martínez-Cagigal
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System;
using System.Text;
using UnityEngine;

public class MedusaTCPClient
{
	// Required instances
	private TcpClient socketConnection;
	private Thread clientReceiveThread;
	private Manager callback;

	// Server IP and port
	// TODO: TAKE THE IP and port from MEDUSA as parameters -exe
	private IPAddress IP;
	private int port;

	// Message reading
	public string END_OF_MESSAGE = "#_?END?_#";
	public string buffer = "";


	/// <summary>
	/// Constructor of the MedusaTCPClient. It provides an asynchronous client that connects to MEDUSA, which is running
	/// a server that sends and receives parameters to and from this client.
	/// </summary>
	/// <param name="manager"> A Manager instance is required as a callback to receive the data. </param>
	/// <param name="serverIP"> IPAddress instance of the server's IP. </param>
	/// <param name="serverPort"> Integer that represents the server's port. </param>
	public MedusaTCPClient(Manager manager, IPAddress serverIP, int serverPort)
	{
		callback = manager;
		this.IP = serverIP;
		this.port = serverPort;
	}

	/// <summary>
	/// This method checks if the client is being connected to the server.
	/// </summary>
	/// <returns>Boolean: true is connected, false otherwise. </returns>
	public bool isConnected()
	{
		if (socketConnection == null)
		{
			return false;
		}
		else
		{
			return true;
		}
	}

	/// <summary>
	/// This method starts the client, which basically creates a thread for listening and initializes the connection.
	/// </summary>
	public void Start()
	{
		try
		{
			clientReceiveThread = new Thread(new ThreadStart(ListenForData));
			clientReceiveThread.IsBackground = true;
			clientReceiveThread.Start();
		}
		catch (Exception e)
		{
			Debug.Log("On client connect exception " + e);
		}
	}

	/// <summary>
	/// This method creates a connection and listens forever to the server in order to check is data is received. If so, 
    /// the method checks if the received message finishes with the string END_OF_MESSAGE, returning the processed data to
    /// the Manager instace (callback).
	/// </summary>
	private void ListenForData()
	{
		try
		{
			socketConnection = new TcpClient(this.IP.ToString(), this.port);
			Byte[] bytes = new Byte[1024];
			Debug.Log("Client listening at " + this.IP.ToString() + ":" + this.port);
			while (true)
			{
				// Get a stream object for reading 				
				using (NetworkStream stream = socketConnection.GetStream())
				{
					int length;
					// Read incomming stream into byte arrary. 					
					while ((length = stream.Read(bytes, 0, bytes.Length)) != 0)
					{
						var incommingData = new byte[length];
						Array.Copy(bytes, 0, incommingData, 0, length);
						// Convert byte array to string message. 						
						string serverMessage = Encoding.ASCII.GetString(incommingData);
						// Detect end of message
						buffer = buffer + serverMessage;
						if (serverMessage.EndsWith(END_OF_MESSAGE))
						{
							buffer = buffer.Remove(buffer.Length - END_OF_MESSAGE.Length);
							callback.interpretMessage(buffer);
							buffer = "";
						}
					}
				}
			}
		}
		catch (SocketException socketException)
		{
			Debug.Log("Socket exception: " + socketException);
			callback.quitApplication();
		}
	}

	/// <summary>
	/// This method sends asynchronously any message to the server, provided the connection has been previously established.
	/// </summary>
	/// <param name="clientMessage"> String that contains the message to send. </param>
	public void SendMessage(string clientMessage)
	{
		if (socketConnection == null)
		{
			return;
		}
		try
		{
			// Get a stream object for writing. 			
			NetworkStream stream = socketConnection.GetStream();
			if (stream.CanWrite)
			{
				// Add the end of message at the end
				clientMessage += END_OF_MESSAGE;
				// Convert string message to byte array.                             
				byte[] clientMessageAsByteArray = Encoding.ASCII.GetBytes(clientMessage);
				// Write byte array to socketConnection stream.                 
				stream.Write(clientMessageAsByteArray, 0, clientMessageAsByteArray.Length);
				Debug.Log("Client sent: " + clientMessage);
			}
		}
		catch (SocketException socketException)
		{
			Debug.Log("Socket exception: " + socketException);
		}
	}

	/// <summary>
	/// This method stops the MedusaTCPClient, killing the listening thread and closing the connection.
	/// </summary>
	public void Stop()
	{
		if (socketConnection != null)
		{
			socketConnection.Close();
		}

		clientReceiveThread.Abort();
		Debug.Log("Client closed");
	}
}
