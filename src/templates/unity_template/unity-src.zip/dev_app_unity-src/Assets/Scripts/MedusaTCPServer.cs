﻿// IT SHOULD NOT BE USED! (for now)

using System.Net;
using System.Net.Sockets;
using System.Threading;
using System;
using System.Text;
using UnityEngine;
//using System.Diagnostics;

public class MedusaTCPServer
{

    private TcpListener tcpListener;
    private Thread tcpListenerThread;
    private TcpClient connectedTcpClient;
	private Manager callback;
	private IPAddress IP;
	private int port;

	public string END_OF_MESSAGE = "#_?END?_#";
	public string buffer = "";

	// Constructor for the server (the parent manager is required as a callback to receive data)
	public MedusaTCPServer(Manager manager, IPAddress IP, int port)
    {
		callback = manager;
		this.IP = IP;
		this.port = port;
    }

	public bool isConnected() 
	{
		if (connectedTcpClient == null)
        {
			return false;
        } else
        {
			return true;
        }
	}

    public void Start()
    {
        // Start TcpServer background thread for listening	
        tcpListenerThread = new Thread(new ThreadStart(ListenForIncommingRequests));
        tcpListenerThread.IsBackground = true;
        tcpListenerThread.Start();
    }

	public void Stop()
	{
		if (connectedTcpClient != null)
		{
			tcpListener.Stop();
		}

		tcpListenerThread.Abort();
		Debug.Log("Server closed");
	}

	/// Runs in background TcpServerThread; Handles incomming TcpClient requests 		
	private void ListenForIncommingRequests()
	{
		try
		{
			// Create listener 			
			tcpListener = new TcpListener(IP, port);
			tcpListener.Start();
			Debug.Log("Server listening");
			Byte[] bytes = new Byte[1024];
			while (true)
			{
				using (connectedTcpClient = tcpListener.AcceptTcpClient())
				{
					// Get a stream object for reading 	
					using (NetworkStream stream = connectedTcpClient.GetStream())
					{
						int length;
						// Read incomming stream into byte arrary. 						
						while ((length = stream.Read(bytes, 0, bytes.Length)) != 0)
						{
							var incomingData = new byte[length];
							Array.Copy(bytes, 0, incomingData, 0, length);
							// Convert byte array to string message. 							
							string clientMessage = Encoding.UTF8.GetString(incomingData);

							Debug.Log("received: " + clientMessage);
							// Detect end of message
							buffer = buffer + clientMessage;
							if (clientMessage.EndsWith(END_OF_MESSAGE))
                            {
								buffer = buffer.Remove(buffer.Length - END_OF_MESSAGE.Length);
								callback.interpretMessage(buffer);
								buffer = "";
							} 						
						}
					}
					
				}
			}
		}
		catch (SocketException socketException)
		{
			Debug.Log("SocketException " + socketException.ToString());
		}
	}

	/// <summary> 	
	/// Send message to client using socket connection. 	
	/// </summary> 	
	public void SendMessage(string serverMessage)
	{
		if (connectedTcpClient == null)
		{
			Debug.LogError("Cannot send anything, there is no connected TCP client!");
			return;
		}

		try
		{
			// Get a stream object for writing. 			
			NetworkStream stream = connectedTcpClient.GetStream();
			if (stream.CanWrite)
			{
				// Add the end of message at the end
				serverMessage += END_OF_MESSAGE;
				// Convert string message to byte array.                 
				byte[] serverMessageAsByteArray = Encoding.ASCII.GetBytes(serverMessage);
				// Write byte array to socketConnection stream.               
				stream.Write(serverMessageAsByteArray, 0, serverMessageAsByteArray.Length);
				Debug.Log("Server sent: " + serverMessage);
			}
		}
		catch (SocketException socketException)
		{
			Debug.LogError("Socket exception: " + socketException);
		}
	}
}
