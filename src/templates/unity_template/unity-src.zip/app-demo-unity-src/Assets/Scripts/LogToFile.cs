﻿using UnityEngine;

public class LogToFile : MonoBehaviour
{
    // Final filename.
    // In build, the path is "PROJECTNAME_Data/[filename]"
    // In debug, the path is ".../Assets/[filename]"
    string filename = "/unity-template-log.txt";

    // Required attribute
    string path = "";  

    /// <summary>
	/// Constructor of the LogToFile class. It takes every single message sent as Debug.Log() and writes it to a file.
	/// </summary>
    public void Log(string logString, string stackTrace, LogType type)
    {
        if (path == "")
        {
            // In build, this path is "NAME_Data/cvep_log.txt"
            // In debug, this path is ".../Assets/cvep_log.txt"
            path = Application.dataPath + filename;
            Debug.Log("Log written in: " + path);
        }

        try
        {
            System.IO.File.AppendAllText(path, logString + "\n");
        }
        catch { }
    }
    void OnEnable() { Application.logMessageReceived += Log; }
    void OnDisable() { Application.logMessageReceived -= Log; }
}