﻿// Example of demo-unity application for MEDUSA 2.0.
//     > (Last edit)
//     > 24/03/2022
//     > Author: Víctor Martínez-Cagigal

using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using UnityEngine;
using UnityEngine.UI;

/*  The Manager class controls the life cycle of the Unity side of the application, i.e., the client side.
 *  
 *  The aim of this example application is to set up a communication with a TCP Server that is controller by 
 *  MEDUSA. So, this code will set up a TCP Client. After parameters are received from MEDUSA, this application 
 *  will request repeatedly to MEDUSA the current amount of recorded EEG samples. MEDUSA will answer, and this
 *  application will receive them and update the GUI. Additionally, whenever we are requesting an update to 
 *  MEDUSA, this application will also flicker an small square in the bottom-left corner of the screen.
 *  
 *  To comprehensively understand this code is important to consider several things. For the sake of clarification, 
 *  these are the most important functions of the Manager class:
 *      - Update(): The Update function is called by the Unity's main thread within a variable rate to update the GUI.
 *                  For that reason, ONLY this function (and FixedUpdate()) will be able to update elements of the GUI,
 *                  threads CANNOT update them! 
 *                  
 *      - FixedUpdate(): The different between FixedUpdate() and Update() is that the former will be called according
 *                  to a desired frame rate. This is ESSENTIAL for applications in which controlling refresh rate is
 *                  critical, such as for c-VEP-based BCI systems. This rate is controlled by 'Time.fixedDeltaTime'
 *                  (for additional details check the OnParametersReady() function).
 *                  
 *                  Therefore, if we want to update things when receiving messages, for instance, we will need to check
 *                  for state changes in these functions (Update and FixedUpdate).
 *                  
 *      - interpretMessage(): This function MUST be implemented if we are using the MedusaTCPClient class, as it serves
 *                  as a callback that is called whenever the TCP Client received a message from MEDUSA. 
 *                  
 *      - CO-ROUTINES (IEnumerator): As we cannot block the life cycle of Update() and FixedUpdate(), we need to set up
 *                  co-routines to make small application flows that must be run in separate threads. For instance, 
 *                  the closingApplication co-routine waits for some seconds and then changes an state to notify the
 *                  Update() function to close the application.
 *                  
 *  As the interpretation of messages in C# is not trivial, please check the code of MessageInterpreter to understand it.
 *                  
 *  A summary of the life cycle is the following:
 *      1) A TCP client is initialized in the Start() function
 *      2) The current state is set up to STATE_WAITING_CONNECTION
 *      3) When the TCP client is connected to the server, Update() changes the state to STATE_WAITING_PARAMS and
 *          sends a "waiting" message to MEDUSA to notify it that we are waiting for the parameters.
 *      4) interpretMessage() will receive the parameters as "setParameters", and onParametersReady() will be called
 *          by the Update() function.
 *      5) onParametersReady() fixes the desired refresh rate for the FixedUpdate() function according to the parameters.
 *      6) State is changed to RUN_STATE_READY and a message "ready" is sent to MEDUSA
 *      7) When MEDUSA answers with "play", state is changed to RUN_STATE_RUNNING 
 *      8) RUN_STATE_RUNNING is detected by the FixedUpdate() function, so it flickers the square and sends a message
 *          "request_samples" to MEDUSA whenever FixedUpdate() is called (at the desired rate)
 *      9) Whenever MEDUSA answers with "samplesUpdate", the boolean mustUpdateSamples is enabled, which is then detected
 *          by Update() and updates the GUI (note: it could be also called by FixedUpdate if desired)
 *      10) This loop continues until user presses PAUSE or STOP. In that case, we would receive them in interpretMessage()
 *          and act accordingly.
 */
public class Manager : MonoBehaviour
{
    // Public parameters
    public string IP = "127.0.0.1";     // Overrided when calling the .exe with parameters
    public int port = 50000;

    // MEDUSA RUN STATES
    const int RUN_STATE_READY = 0;           // READY
    const int RUN_STATE_RUNNING = 1;         // RUNNING
    const int RUN_STATE_PAUSED = 2;          // PAUSED
    const int RUN_STATE_STOP = 3;            // TRANSITORY STATE WHILE USER PRESS THE STOP BUTTON AND MEDUSA IS READY TO START A NEW RUN AGAIN
    const int RUN_STATE_FINISHED = 4;        // THE RUN IS STILL ACTIVE, BUT FINISHED
    
    // Inner states
    const int STATE_WAITING_CONNECTION = -2;    // previous states of "state"
    const int STATE_WAITING_PARAMS = -1;
    const int STATE_CLOSING_TEXT = 27;          // states of "closingstate" of closingApplication()
    const int STATE_CLOSING_FINAL = 28;

    // State controllers and coroutines
    static int state = STATE_WAITING_CONNECTION;
    static int closingstate = STATE_CLOSING_TEXT;
    static bool mustClose = false;
    static bool mustUpdateSamples = false;

    // FPS counter
    private float updateCount = 0;
    private float fixedUpdateCount = 0;
    private float updateUpdateCountPerSecond;
    private float updateFixedUpdateCountPerSecond;

    // Other attributes
    public int updates_per_min = 0;
    public int no_samples = 0;
    private MessageInterpreter.ParameterDecoder parameters = null;
    private MessageInterpreter messageInterpreter = new MessageInterpreter();
    private GameObject fpsMonitorText, informationBox, informationText, counterText, photodiodeCell;
    public Color32 defaultBoxColor = new Color32(255, 255, 255, 255);
    public Color32 highlightBoxColor = new Color32(75, 75, 75, 255);

    // TCP client
    private MedusaTCPClient tcpClient;   

    /* ----------------------------------- UNITY LIFE-CYCLE FUNCTIONS ------------------------------------ */

    void Awake()
    {
        // Take the IP and port from the arguments
        // Usage: app-demo-unity-src.exe 127.0.0.1 65432
        string[] arguments = Environment.GetCommandLineArgs();
        IP = arguments[1];
        port = Int32.Parse(arguments[2]);
    }

    // Start is called before the first frame update
    void Start()
    {
        // Start the TCP/IP server
        tcpClient = new MedusaTCPClient(this, IPAddress.Parse(IP), port);
        tcpClient.Start();

        // FPS monitoring
        fpsMonitorText = GameObject.Find("FPSmonitor");
        StartCoroutine(monitorFPS());

        // Information texts and box
        informationBox = GameObject.Find("InformationBox");
        informationText = GameObject.Find("InformationText");
        counterText = GameObject.Find("CounterText");

        // Find the photodiode cell object
        photodiodeCell = GameObject.Find("Photodiode_Cell");

        // WAIT until parameters are received!
        state = STATE_WAITING_CONNECTION;
    }

    // Show the FPS monitoring: current FPS and refresh rate
    void OnGUI()
    {
        fpsMonitorText.GetComponent<Text>().text = updateUpdateCountPerSecond.ToString() + " fps (fixed @" + updateFixedUpdateCountPerSecond.ToString() + " Hz)";
    }
    
    // This function quits the current application by stopping the TCP client and closing the window
    public void quitApplication()
    {
        tcpClient.Stop();
        Application.Quit();
    }

    // This function starts the closing coroutine form the MainThread in Update()
    public void quitApplicationFromException()
    {
        mustClose = true;
    }


    /* ------------------------------------- UPDATE THINGS -------------------------------------- */

    // Update call (FPS may vary)
    void Update()
    {
        updateCount += 1;

        /* BEHAVIOR FOR DIFFERENT STATES (MAIN THREAD) */
        // If the TCP client just connected, request the parameters
        if (state == STATE_WAITING_CONNECTION && tcpClient.isConnected())
        {
            state = STATE_WAITING_PARAMS;
            // If the connection have been just established, send the waiting flag
            ServerMessage sm = new ServerMessage("waiting");
            tcpClient.SendMessage(sm.ToJson());
        }

        // If we are waiting the parameters
        if (state == STATE_WAITING_PARAMS)
        {
            // If parameters have been already received, execute this in the main thread
            if (parameters != null)
            {
                onParametersReady();
            }
        }

        // If MEDUSA is paused
        if (state == RUN_STATE_PAUSED)
        {
            setInformationText("Paused");
        }

        // If the Unity app is stopping (closing)
        if (state == RUN_STATE_STOP)
        {
            if (closingstate == STATE_CLOSING_TEXT)
            {
                setInformationText("Closing...");
                setCounterText("");
            }
            if (closingstate == STATE_CLOSING_FINAL)
            {
                quitApplication();
                //EditorApplication.Exit(0);
            }
        }

        /* EXECUTING CO-ROUTINES*/

        // If we must update the number of samples in the GUI
        if (mustUpdateSamples)
        {
            setInformationText("Running...");
            setCounterText("EEG samples: " + no_samples.ToString());
            mustUpdateSamples = false;
        }

        // If the TCPServer must close
        if (mustClose)
        {
            if (tcpClient.socketConnection != null)
            {
                // Send the confirmation that the Unity's client is going to close
                ServerMessage sm = new ServerMessage("close");
                tcpClient.SendMessage(sm.ToJson());
            }

            // Close the application
            mustClose = false;         // Avoid sending it twice
            StartCoroutine(closingApplication());
        }
    }

    // Fixed update at the rate controlled by 'updates_per_min'
    void FixedUpdate()
    {
        fixedUpdateCount += 1;

        // Update the counter
        if (state == RUN_STATE_RUNNING)
        {
            // Flicker the photodiode
            if (photodiodeCell.GetComponent<Image>().color == highlightBoxColor)
            {
                photodiodeCell.GetComponent<Image>().color = defaultBoxColor;
            }
            else if (photodiodeCell.GetComponent<Image>().color == defaultBoxColor)
            {
                photodiodeCell.GetComponent<Image>().color = highlightBoxColor;
            }

            // Request the number of EEG samples to MEDUSA
            ServerMessage sm = new ServerMessage("request_samples");
            sm.addValue("dummy", "value");      // Example for adding more attributes to the message (not used)
            tcpClient.SendMessage(sm.ToJson());
        }
       
    }

    // This function sets the information text. IMPORTANT: only the main thread is allowed to run this function.
    void setInformationText(string infoMsg)
    {
        if (string.IsNullOrEmpty(infoMsg))
        {
            informationText.SetActive(false);
        }
        else
        {
            informationText.SetActive(true);
            informationText.GetComponent<Text>().text = infoMsg;
        }
    }

    // This function sets the counter text. IMPORTANT: only the main thread is allowed to run this function.
    void setCounterText(string infoMsg)
    {
        if (string.IsNullOrEmpty(infoMsg))
        {
            counterText.SetActive(false);
        }
        else
        {
            counterText.SetActive(true);
            counterText.GetComponent<Text>().text = infoMsg;
        }
    }

    /* ------------------------------------------- COMMUNICATION ------------------------------------------- */

    // This function is called by the MedusaTCPClient whenever a packet is received in order to interpret it
    public void interpretMessage(string message)
    {
        Debug.Log("Received from server: " + message);
        string eventType = messageInterpreter.decodeEventType(message);
        switch (eventType)
        {
            case "play":
                if (state != STATE_WAITING_PARAMS)
                {
                    state = RUN_STATE_RUNNING;
                }
                break;
            case "pause":
                if (state != STATE_WAITING_PARAMS)
                {
                    state = RUN_STATE_PAUSED;
                }
                break;
            case "resume":
                if (state != STATE_WAITING_PARAMS)
                {
                    state = RUN_STATE_RUNNING;
                }
                break;
            case "stop":
                state = RUN_STATE_STOP;
                mustClose = true;       // Update() will recognize it and start a coroutine
                break;
            case "setParameters":
                // The main thread will detect that parameters are here using Update() and will call onParametersReady() itself
                parameters = messageInterpreter.decodeParameters(message);
                Debug.Log("Parameters received.");
                break;
            case "samplesUpdate":
                // We have received an update of the number of EEG samples from MEDUSA, we must notify the main thread to update the GUI
                mustUpdateSamples = true;
                no_samples = messageInterpreter.decodeSamples(message);
                break;
            case "exception":
                string exception = messageInterpreter.decodeException(message);
                Debug.LogError("Exception from client, aborting: " + exception);
                state = RUN_STATE_STOP;

                tcpClient.socketConnection.Close();
                tcpClient.socketConnection = null;
                mustClose = true;
                break;
            default:
                Debug.LogError("Unknown action!");
                break;
        }
    }

    // This function is called by the main thread when parameters are ready
    void onParametersReady()
    {
        // Extract the parameters
        updates_per_min = parameters.updates_per_min;
        
        // Set up the fixedDeltaTime to the desired frame rate for the clock
        Application.targetFrameRate = -1;
        Time.fixedDeltaTime = ((float) 60 / updates_per_min); // in seconds

        // Change state
        state = RUN_STATE_READY;
        ServerMessage sm = new ServerMessage("ready");
        tcpClient.SendMessage(sm.ToJson());
        setInformationText("Waiting to start...");
        setCounterText("");
    }

    /* ------------------------------------------- CO-ROUTINES ------------------------------------------- */

    // This thread controls the FPS rate
    IEnumerator monitorFPS()
    {
        while (true)
        {
            yield return new WaitForSeconds(1);
            updateUpdateCountPerSecond = updateCount;
            updateFixedUpdateCountPerSecond = fixedUpdateCount;

            updateCount = 0;
            fixedUpdateCount = 0;
        }
    }
     
    // This thread controls the timings for closing the application.
    IEnumerator closingApplication()
    {
        Debug.Log("Closing...");
        closingstate = STATE_CLOSING_TEXT;
        yield return new WaitForSeconds(1);

        closingstate = STATE_CLOSING_FINAL;
    }
}
